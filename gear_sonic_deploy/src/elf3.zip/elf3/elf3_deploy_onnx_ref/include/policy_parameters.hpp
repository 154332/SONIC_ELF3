/**
 * @file policy_parameters.hpp
 * @brief ELF3 policy-side joint ordering, gains, action scales and default pose.
 *
 * Values match gear_sonic/envs/manager_env/robots/elf3.py used for training:
 * action_scale=0.25*effort_limit_sim/stiffness.
 */
#ifndef POLICY_PARAMETERS_HPP
#define POLICY_PARAMETERS_HPP
#include <array>
#include <vector>
#include "robot_parameters.hpp"
const double ONE_DEGREE=0.0174533;
const double ARMATURE_HIGH=0.044688;
const double ARMATURE_MEDIUM=0.0137351;
const double ARMATURE_LOW=0.00424198;
const double ARMATURE_FOOT=0.00551458;
const double NATURAL_FREQ=10.0*2.0*3.1415926535;
const double DAMPING_RATIO=2.0;
const double STIFFNESS_HIGH=ARMATURE_HIGH*NATURAL_FREQ*NATURAL_FREQ;
const double STIFFNESS_MEDIUM=ARMATURE_MEDIUM*NATURAL_FREQ*NATURAL_FREQ;
const double STIFFNESS_LOW=ARMATURE_LOW*NATURAL_FREQ*NATURAL_FREQ;
const double STIFFNESS_FOOT=ARMATURE_FOOT*NATURAL_FREQ*NATURAL_FREQ;
const double DAMPING_HIGH=2.0*DAMPING_RATIO*ARMATURE_HIGH*NATURAL_FREQ;
const double DAMPING_MEDIUM=2.0*DAMPING_RATIO*ARMATURE_MEDIUM*NATURAL_FREQ;
const double DAMPING_LOW=2.0*DAMPING_RATIO*ARMATURE_LOW*NATURAL_FREQ;
const double DAMPING_FOOT=2.0*DAMPING_RATIO*ARMATURE_FOOT*NATURAL_FREQ;
const double EFFORT_HIGH=150.0;
const double EFFORT_MEDIUM=150.0;
const double EFFORT_ARM=50.0;
const double EFFORT_FOOT=50.0;
const double EFFORT_HEAD=20.0;
// IsaacLab body indices: left wrist, right wrist, torso, left ankle, right ankle.
const std::array<int,5> vr_5point_index={24,25,0,30,31};
const std::array<int,3> vr_3point_index={24,25,0};
// Upper body excludes the two head DOFs to preserve SONIC's 17-DOF upper-body interface.
const std::vector<int> upper_body_joint_mujoco_order_in_isaaclab_index={3,7,10,1,5,8,11,15,19,23,2,6,9,12,16,20,24};
const std::vector<int> upper_body_joint_mujoco_order_in_mujoco_index={0,1,2,15,16,17,18,19,20,21,22,23,24,25,26,27,28};
const std::vector<int> upper_body_joint_isaaclab_order_in_isaaclab_index={1,2,3,5,6,7,8,9,10,11,12,15,16,19,20,23,24};
const std::vector<int> upper_body_joint_isaaclab_order_in_mujoco_index={15,22,0,16,23,1,17,24,2,18,25,19,26,20,27,21,28};
const std::vector<int> wrist_joint_mujoco_order_in_isaaclab_index={15,19,23,16,20,24};
const std::vector<int> wrist_joint_mujoco_order_in_mujoco_index={19,20,21,26,27,28};
const std::vector<int> wrist_joint_isaaclab_order_in_isaaclab_index={15,16,19,20,23,24};
const std::vector<int> wrist_joint_isaaclab_order_in_mujoco_index={19,26,20,27,21,28};
const std::vector<int> lower_body_joint_mujoco_order_in_isaaclab_index={13,17,21,25,27,29,14,18,22,26,28,30};
const std::vector<int> lower_body_joint_mujoco_order_in_mujoco_index={3,4,5,6,7,8,9,10,11,12,13,14};
const std::vector<int> lower_body_joint_isaaclab_order_in_isaaclab_index={13,14,17,18,21,22,25,26,27,28,29,30};
const std::vector<int> lower_body_joint_isaaclab_order_in_mujoco_index={3,9,4,10,5,11,6,12,7,13,8,14};
// output_mujoco[i]=input_isaaclab[isaaclab_to_mujoco[i]].
const std::array<int,ELF3_NUM_MOTOR> isaaclab_to_mujoco={3,7,10,13,17,21,25,27,29,14,18,22,26,28,30,1,5,8,11,15,19,23,2,6,9,12,16,20,24,0,4};
// output_isaaclab[i]=input_mujoco[mujoco_to_isaaclab[i]].
const std::array<int,ELF3_NUM_MOTOR> mujoco_to_isaaclab={29,15,22,0,30,16,23,1,17,24,2,18,25,3,9,19,26,4,10,20,27,5,11,21,28,6,12,7,13,8,14};
const std::array<double,ELF3_NUM_MOTOR> elf3_action_scale={
    0.25*EFFORT_MEDIUM/STIFFNESS_MEDIUM,0.25*EFFORT_MEDIUM/STIFFNESS_MEDIUM,0.25*EFFORT_MEDIUM/STIFFNESS_MEDIUM,
    0.25*EFFORT_HIGH/STIFFNESS_HIGH,0.25*EFFORT_HIGH/STIFFNESS_HIGH,0.25*EFFORT_HIGH/STIFFNESS_HIGH,0.25*EFFORT_HIGH/STIFFNESS_HIGH,0.25*EFFORT_FOOT/STIFFNESS_FOOT,0.25*EFFORT_FOOT/STIFFNESS_FOOT,
    0.25*EFFORT_HIGH/STIFFNESS_HIGH,0.25*EFFORT_HIGH/STIFFNESS_HIGH,0.25*EFFORT_HIGH/STIFFNESS_HIGH,0.25*EFFORT_HIGH/STIFFNESS_HIGH,0.25*EFFORT_FOOT/STIFFNESS_FOOT,0.25*EFFORT_FOOT/STIFFNESS_FOOT,
    0.25*EFFORT_ARM/STIFFNESS_LOW,0.25*EFFORT_ARM/STIFFNESS_LOW,0.25*EFFORT_ARM/STIFFNESS_LOW,0.25*EFFORT_ARM/STIFFNESS_LOW,0.25*EFFORT_ARM/STIFFNESS_LOW,0.25*EFFORT_ARM/STIFFNESS_LOW,0.25*EFFORT_ARM/STIFFNESS_LOW,
    0.25*EFFORT_ARM/STIFFNESS_LOW,0.25*EFFORT_ARM/STIFFNESS_LOW,0.25*EFFORT_ARM/STIFFNESS_LOW,0.25*EFFORT_ARM/STIFFNESS_LOW,0.25*EFFORT_ARM/STIFFNESS_LOW,0.25*EFFORT_ARM/STIFFNESS_LOW,0.25*EFFORT_ARM/STIFFNESS_LOW,
    0.25*EFFORT_HEAD/STIFFNESS_LOW,0.25*EFFORT_HEAD/STIFFNESS_LOW
};
const std::array<float,ELF3_NUM_MOTOR> kps={
    STIFFNESS_MEDIUM,STIFFNESS_MEDIUM,STIFFNESS_MEDIUM,
    STIFFNESS_HIGH,STIFFNESS_HIGH,STIFFNESS_HIGH,STIFFNESS_HIGH,STIFFNESS_FOOT,STIFFNESS_FOOT,
    STIFFNESS_HIGH,STIFFNESS_HIGH,STIFFNESS_HIGH,STIFFNESS_HIGH,STIFFNESS_FOOT,STIFFNESS_FOOT,
    STIFFNESS_LOW,STIFFNESS_LOW,STIFFNESS_LOW,STIFFNESS_LOW,STIFFNESS_LOW,STIFFNESS_LOW,STIFFNESS_LOW,
    STIFFNESS_LOW,STIFFNESS_LOW,STIFFNESS_LOW,STIFFNESS_LOW,STIFFNESS_LOW,STIFFNESS_LOW,STIFFNESS_LOW,
    STIFFNESS_LOW,STIFFNESS_LOW
};
const std::array<float,ELF3_NUM_MOTOR> kds={
    DAMPING_MEDIUM,DAMPING_MEDIUM,DAMPING_MEDIUM,
    DAMPING_HIGH,DAMPING_HIGH,DAMPING_HIGH,DAMPING_HIGH,DAMPING_FOOT,DAMPING_FOOT,
    DAMPING_HIGH,DAMPING_HIGH,DAMPING_HIGH,DAMPING_HIGH,DAMPING_FOOT,DAMPING_FOOT,
    DAMPING_LOW,DAMPING_LOW,DAMPING_LOW,DAMPING_LOW,DAMPING_LOW,DAMPING_LOW,DAMPING_LOW,
    DAMPING_LOW,DAMPING_LOW,DAMPING_LOW,DAMPING_LOW,DAMPING_LOW,DAMPING_LOW,DAMPING_LOW,
    DAMPING_LOW,DAMPING_LOW
};
const std::array<double,ELF3_NUM_MOTOR> default_angles={
    0.0,0.0,0.0,
    0.0,0.0,0.0,0.3,0.0,0.0,
    0.0,0.0,0.0,0.3,0.0,0.0,
    0.0,0.0,0.0,0.0,0.0,0.0,0.0,
    0.0,0.0,0.0,0.0,0.0,0.0,0.0,
    0.0,0.0
};
#endif
